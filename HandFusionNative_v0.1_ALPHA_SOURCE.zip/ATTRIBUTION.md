# Attribution and design references

Este projeto foi escrito como implementação própria.

- Google Cardboard XR Plugin: Apache License 2.0.
- EnJoyTheVR: conceitos de apps modulares, AssetBundles e Lua; repositório MIT.
- EnJoyTheMR: referência conceitual para manifestos, permissões e loja.
- Reality Fusion: referência conceitual para Cardboard, MediaPipe, browser e 3DoF.

Nenhum código do Reality Fusion foi copiado, pois o repositório consultado
não apresentava uma licença permissiva clara na página principal.
