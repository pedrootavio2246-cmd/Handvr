# HandFusion Native v0.1 Alpha

Projeto Unity para transformar o HandFusion em uma plataforma VR/MR para
celulares Android usados em VR Box.

## O que já existe nesta base

- interface espacial em canvas 3D;
- Google Cardboard por pacote oficial;
- dock com aplicativos;
- janelas móveis e multitarefa;
- duas miras independentes;
- pinça com suavização, histerese, tempo mínimo sobre o alvo e cooldown;
- fallback por mouse, toque e mira central;
- navegador Alpha;
- teclado virtual grande;
- calculadora funcional;
- cinema para URLs diretas de vídeo;
- jogo Pinch Arena;
- loja modular;
- configurações de desempenho;
- central de testes;
- exportação de relatório JSON;
- estrutura de pacotes `app.json`;
- script para gerar APK de desenvolvimento.

## Abrir o projeto

1. Instale Unity `6000.0.23f1` ou mais recente com Android Build Support.
2. Abra esta pasta pelo Unity Hub.
3. Aguarde o Package Manager baixar o Cardboard.
4. A cena `Assets/Scenes/HandFusionMain.unity` será criada automaticamente.
5. Abra `Edit > Project Settings > XR Plug-in Management`.
6. Na aba Android, ative `Cardboard`.
7. Use `HandFusion > Gerar APK Alpha`.

O APK será criado em:

```text
Builds/Android/HandFusionNative-Alpha.apk
```

## Testar no Editor

- mouse controla a mão esquerda;
- segure `Espaço` para fechar a pinça;
- segure `Alt esquerdo` para simular a mão direita;
- sem mãos, a mira central funciona com clique/toque.

## Hand tracking real

A interface `MediaPipeJsonProvider` já recebe quadros de duas mãos por JSON.
O plugin Android deve enviar dados para:

```text
GameObject: HandTrackingProvider
Method: OnLandmarksJson
```

Consulte `Docs/MEDIAPIPE_ANDROID.md`.

## Aviso

Este pacote é o código-fonte Alpha. O ambiente desta conversa não possui
Unity Editor nem Android SDK completo, então o APK não foi compilado aqui.
