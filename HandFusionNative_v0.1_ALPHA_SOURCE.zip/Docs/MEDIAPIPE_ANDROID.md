# Integração MediaPipe

O projeto compila e pode ser testado pelo fallback sem MediaPipe.

Para duas mãos reais no Android, use o pacote pré-compilado do
MediaPipeUnityPlugin compatível com Unity 6, ou uma ponte Android própria.

## Formato esperado

Envie um JSON para:

```java
UnityPlayer.UnitySendMessage(
    "HandTrackingProvider",
    "OnLandmarksJson",
    json
);
```

Exemplo:

```json
{
  "timestamp": 1720000000000,
  "hands": [
    {
      "handedness": "Left",
      "confidence": 0.98,
      "landmarks": [
        {"x": 0.51, "y": 0.82, "z": 0.01}
      ]
    }
  ]
}
```

Cada mão precisa de 21 landmarks.

## Configuração recomendada

- máximo de mãos: 2;
- confiança de detecção: 0.55;
- confiança de presença: 0.50;
- confiança de tracking: 0.50;
- modo fraco: 12 a 15 inferências por segundo;
- modo equilibrado: 18 a 24 inferências por segundo;
- resolução de entrada: 640×360 ou 640×480;
- pipeline assíncrono;
- não desenhar esqueleto completo por padrão.

## Libstdc++

Nas versões recentes do MediaPipeUnityPlugin, confira se
`libstdc++_shared.so` está incluído no APK Android.
