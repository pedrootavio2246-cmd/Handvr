# Guia do tester

## Teste 1 — Interface

- abrir todos os aplicativos do dock;
- mover janelas;
- fechar e reabrir janelas;
- recentralizar a interface.

## Teste 2 — Miras

- apontar para cinco botões pequenos;
- aproximar polegar e indicador;
- confirmar se a mira muda de cor;
- fechar a pinça;
- verificar se ocorre apenas um clique;
- repetir com a mão esquerda e direita.

## Teste 3 — Teclado

- escrever `handfusion teste`;
- apagar três letras;
- usar espaço;
- pressionar buscar;
- anotar teclas difíceis.

## Teste 4 — Pinch Arena

- jogar por 60 segundos;
- informar pontuação;
- informar se a mira treme;
- informar se o clique atrasa.

## Teste 5 — Desempenho

Testar os perfis:

- Economia;
- Equilibrado;
- Qualidade.

Anotar:

- FPS;
- aquecimento;
- consumo de bateria;
- travamentos;
- modelo do celular.

## Relatório

Abra `Central Tester`, escreva o problema e salve o relatório JSON.
