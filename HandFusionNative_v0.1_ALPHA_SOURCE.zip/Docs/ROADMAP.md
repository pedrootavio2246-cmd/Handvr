# Roadmap

## Alpha 1

- Cardboard;
- dock;
- janelas;
- retículas;
- pinça;
- apps integrados;
- relatório de testers.

## Alpha 2

- ponte MediaPipe Android completa;
- câmera estereoscópica;
- mãos 3D opcionais;
- teclado curvo;
- calibração por aparelho;
- browser WebView espacial.

## Alpha 3

- pacotes `.hfapp`;
- Lua isolado;
- permissões;
- download e atualização de apps;
- AssetBundles assinados;
- armazenamento por aplicativo.

## Beta

- perfil automático de desempenho;
- resolução dinâmica;
- gravação de sessão;
- áudio espacial;
- cinema 180/360;
- jogos multiplayer simples;
- controle Bluetooth;
- sistema de segurança de módulos.
