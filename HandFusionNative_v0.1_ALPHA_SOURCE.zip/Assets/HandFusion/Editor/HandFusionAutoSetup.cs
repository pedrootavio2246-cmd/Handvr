#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace HandFusion.Editor
{
    [InitializeOnLoad]
    public static class HandFusionAutoSetup
    {
        private const string SceneFolder = "Assets/Scenes";
        private const string ScenePath =
            "Assets/Scenes/HandFusionMain.unity";

        static HandFusionAutoSetup()
        {
            EditorApplication.delayCall += EnsureProject;
        }

        [MenuItem("HandFusion/Recriar cena principal")]
        public static void RebuildScene()
        {
            CreateScene(true);
        }

        [MenuItem("HandFusion/Aplicar configurações Android")]
        public static void ConfigureAndroid()
        {
            PlayerSettings.companyName = "HandFusion";
            PlayerSettings.productName = "HandFusion Native";
            PlayerSettings.SetApplicationIdentifier(
                BuildTargetGroup.Android,
                "com.handfusion.native"
            );
            PlayerSettings.defaultInterfaceOrientation =
                UIOrientation.LandscapeLeft;
            PlayerSettings.Android.minSdkVersion =
                AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetArchitectures =
                AndroidArchitecture.ARM64;
            PlayerSettings.SetScriptingBackend(
                NamedBuildTarget.Android,
                ScriptingImplementation.IL2CPP
            );
            PlayerSettings.colorSpace = ColorSpace.Gamma;
            PlayerSettings.MTRendering = true;
            PlayerSettings.runInBackground = true;

            QualitySettings.vSyncCount = 0;
            Debug.Log("HandFusion: configurações Android aplicadas.");
        }

        private static void EnsureProject()
        {
            if (!File.Exists(ScenePath))
            {
                CreateScene(false);
            }

            ConfigureAndroid();
        }

        private static void CreateScene(bool force)
        {
            if (File.Exists(ScenePath) && !force)
            {
                return;
            }

            if (!Directory.Exists(SceneFolder))
            {
                Directory.CreateDirectory(SceneFolder);
            }

            var scene = EditorSceneManager.NewScene(
                NewSceneSetup.EmptyScene,
                NewSceneMode.Single
            );

            var cameraObject = new GameObject(
                "Main Camera",
                typeof(Camera),
                typeof(AudioListener)
            );
            cameraObject.tag = "MainCamera";
            cameraObject.transform.position = Vector3.zero;
            cameraObject.transform.rotation = Quaternion.identity;

            var camera = cameraObject.GetComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = HandFusionTheme.Background;
            camera.nearClipPlane = 0.01f;
            camera.farClipPlane = 100f;

            var bootstrap = new GameObject(
                "HandFusion",
                typeof(HandFusionBootstrap)
            );
            bootstrap.transform.position = Vector3.zero;

            EditorSceneManager.SaveScene(scene, ScenePath);

            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(ScenePath, true)
            };

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            EditorSceneManager.OpenScene(ScenePath);

            Debug.Log(
                "HandFusion: cena principal criada. " +
                "Ative Cardboard em XR Plug-in Management > Android."
            );
        }
    }
}
#endif
