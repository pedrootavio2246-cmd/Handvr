#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace HandFusion.Editor
{
    public static class BuildAndroid
    {
        [MenuItem("HandFusion/Gerar APK Alpha")]
        public static void BuildFromMenu()
        {
            Build();
        }

        public static void Build()
        {
            HandFusionAutoSetup.ConfigureAndroid();

            var outputDirectory = Path.Combine(
                Directory.GetCurrentDirectory(),
                "Builds",
                "Android"
            );
            Directory.CreateDirectory(outputDirectory);

            var outputPath = Path.Combine(
                outputDirectory,
                "HandFusionNative-Alpha.apk"
            );

            EditorUserBuildSettings.buildAppBundle = false;
            EditorUserBuildSettings.SwitchActiveBuildTarget(
                BuildTargetGroup.Android,
                BuildTarget.Android
            );

            var options = new BuildPlayerOptions
            {
                scenes = new[] {"Assets/Scenes/HandFusionMain.unity"},
                locationPathName = outputPath,
                target = BuildTarget.Android,
                options = BuildOptions.Development |
                    BuildOptions.AllowDebugging
            };

            var report = BuildPipeline.BuildPlayer(options);
            if (
                report.summary.result !=
                BuildResult.Succeeded)
            {
                throw new Exception(
                    $"Build falhou: {report.summary.result}"
                );
            }

            Debug.Log(
                $"HandFusion APK criado em: {outputPath}"
            );
        }
    }
}
#endif
