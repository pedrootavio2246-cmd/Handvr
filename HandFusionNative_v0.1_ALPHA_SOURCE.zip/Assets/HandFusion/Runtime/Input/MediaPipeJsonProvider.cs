using UnityEngine;

namespace HandFusion.Input
{
    /// <summary>
    /// Receives hand frames from an Android/MediaPipe bridge using:
    /// UnityPlayer.UnitySendMessage("HandTrackingProvider", "OnLandmarksJson", json)
    ///
    /// Expected JSON:
    /// {
    ///   "timestamp": 123,
    ///   "hands": [
    ///     {
    ///       "handedness": "Left",
    ///       "confidence": 0.98,
    ///       "landmarks": [{"x":0.5,"y":0.5,"z":0.0}, ... 21]
    ///     }
    ///   ]
    /// }
    /// </summary>
    public sealed class MediaPipeJsonProvider : MonoBehaviour, IHandProvider
    {
        private readonly object _sync = new object();
        private HandFrame _latest = new HandFrame();
        private bool _hasFrame;

        public bool IsReady => _hasFrame;

        public void OnLandmarksJson(string json)
        {
            if (string.IsNullOrWhiteSpace(json))
            {
                return;
            }

            try
            {
                var parsed = JsonUtility.FromJson<HandFrame>(json);
                if (parsed == null)
                {
                    return;
                }

                lock (_sync)
                {
                    _latest = parsed;
                    _hasFrame = true;
                }
            }
            catch (System.Exception exception)
            {
                Debug.LogWarning($"HandFusion: invalid hand JSON: {exception.Message}");
            }
        }

        public bool TryGetFrame(out HandFrame frame)
        {
            lock (_sync)
            {
                frame = _latest;
                return _hasFrame;
            }
        }
    }
}
