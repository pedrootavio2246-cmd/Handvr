using System;
using UnityEngine;

namespace HandFusion.Input
{
    /// <summary>
    /// Editor and emergency fallback.
    /// Mouse = left hand. Hold Space = pinch.
    /// Hold Left Alt = right hand. Alt + Space = right pinch.
    /// On a phone without MediaPipe, touch acts as a single pointer.
    /// </summary>
    public sealed class EditorPointerProvider : MonoBehaviour, IHandProvider
    {
        private readonly HandFrame _frame = new HandFrame();
        private readonly TrackedHand _left = CreateHand("Left");
        private readonly TrackedHand _right = CreateHand("Right");

        public bool IsReady => true;

        public bool TryGetFrame(out HandFrame frame)
        {
            var hands = Array.Empty<TrackedHand>();

            if (UnityEngine.InputSystem.Mouse.current != null)
            {
                var position = UnityEngine.InputSystem.Mouse.current.position.ReadValue();
                var normalized = new Vector2(
                    Mathf.Clamp01(position.x / Mathf.Max(1f, Screen.width)),
                    Mathf.Clamp01(1f - position.y / Mathf.Max(1f, Screen.height))
                );

                var keyboard = UnityEngine.InputSystem.Keyboard.current;
                var rightMode = keyboard != null && keyboard.leftAltKey.isPressed;
                var pinching = keyboard != null && keyboard.spaceKey.isPressed;

                var selected = rightMode ? _right : _left;
                FillLandmarks(selected, normalized, pinching);
                hands = new[] { selected };
            }
            else if (UnityEngine.InputSystem.Touchscreen.current != null)
            {
                var touch = UnityEngine.InputSystem.Touchscreen.current.primaryTouch;
                if (touch.press.isPressed)
                {
                    var position = touch.position.ReadValue();
                    var normalized = new Vector2(
                        Mathf.Clamp01(position.x / Mathf.Max(1f, Screen.width)),
                        Mathf.Clamp01(1f - position.y / Mathf.Max(1f, Screen.height))
                    );

                    FillLandmarks(_left, normalized, true);
                    hands = new[] { _left };
                }
            }

            _frame.timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            _frame.hands = hands;
            frame = _frame;
            return true;
        }

        private static TrackedHand CreateHand(string handedness)
        {
            return new TrackedHand
            {
                handedness = handedness,
                confidence = 1f,
                landmarks = new HandPoint[21]
            };
        }

        private static void FillLandmarks(
            TrackedHand hand,
            Vector2 pointer,
            bool pinching)
        {
            for (var index = 0; index < hand.landmarks.Length; index++)
            {
                hand.landmarks[index] = new HandPoint
                {
                    x = pointer.x,
                    y = pointer.y,
                    z = 0f
                };
            }

            // Wrist and middle MCP define a stable palm size.
            hand.landmarks[0] = new HandPoint
            {
                x = pointer.x,
                y = Mathf.Clamp01(pointer.y + 0.13f),
                z = 0f
            };
            hand.landmarks[9] = new HandPoint
            {
                x = pointer.x,
                y = Mathf.Clamp01(pointer.y + 0.04f),
                z = 0f
            };

            hand.landmarks[8] = new HandPoint
            {
                x = pointer.x,
                y = pointer.y,
                z = 0f
            };

            hand.landmarks[4] = new HandPoint
            {
                x = Mathf.Clamp01(pointer.x + (pinching ? 0.008f : 0.075f)),
                y = Mathf.Clamp01(pointer.y + (pinching ? 0.006f : 0.015f)),
                z = 0f
            };
        }
    }
}
