using System;
using UnityEngine;

namespace HandFusion.Input
{
    [Serializable]
    public struct HandPoint
    {
        public float x;
        public float y;
        public float z;

        public Vector3 ToVector3()
        {
            return new Vector3(x, y, z);
        }
    }

    [Serializable]
    public sealed class TrackedHand
    {
        public string handedness = "Unknown";
        public float confidence = 1f;
        public HandPoint[] landmarks = Array.Empty<HandPoint>();

        public bool IsValid => landmarks != null && landmarks.Length >= 21;
    }

    [Serializable]
    public sealed class HandFrame
    {
        public long timestamp;
        public TrackedHand[] hands = Array.Empty<TrackedHand>();
    }

    public interface IHandProvider
    {
        bool IsReady { get; }
        bool TryGetFrame(out HandFrame frame);
    }
}
