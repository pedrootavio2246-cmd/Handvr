using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace HandFusion.Input
{
    public sealed class HandInputRouter : MonoBehaviour
    {
        [Header("Sources")]
        [SerializeField] private MonoBehaviour primaryProviderBehaviour;
        [SerializeField] private MonoBehaviour fallbackProviderBehaviour;
        [SerializeField] private Camera eventCamera;
        [SerializeField] private GraphicRaycaster raycaster;
        [SerializeField] private EventSystem eventSystem;

        [Header("Interaction")]
        [Range(0.2f, 0.5f)]
        [SerializeField] private float pinchCloseThreshold = 0.31f;
        [Range(0.35f, 0.8f)]
        [SerializeField] private float pinchReleaseThreshold = 0.53f;
        [Range(0f, 0.95f)]
        [SerializeField] private float steadySmoothing = 0.68f;
        [SerializeField] private float targetHoldSeconds = 0.07f;
        [SerializeField] private float clickCooldownSeconds = 0.22f;
        [SerializeField] private bool gazeFallback = true;

        private readonly Dictionary<string, HandPointerState> _states = new();
        private readonly List<RaycastResult> _results = new();

        private IHandProvider _primary;
        private IHandProvider _fallback;
        private RectTransform _reticleLayer;
        private RectTransform _leftReticle;
        private RectTransform _rightReticle;
        private float _lastRealHandTime;
        private GameObject _gazePressedTarget;

        public int VisibleHandCount { get; private set; }
        public string DebugState { get; private set; } = "Sem mãos";

        private sealed class HandPointerState
        {
            public Vector2 filtered;
            public bool initialized;
            public bool closedLatch;
            public float lastClickTime = -100f;
            public GameObject hoverTarget;
            public float hoverStartTime;
            public GameObject pressedTarget;
            public PointerEventData eventData;
        }

        public void Configure(
            MonoBehaviour primary,
            MonoBehaviour fallback,
            Camera camera,
            GraphicRaycaster graphicRaycaster,
            EventSystem system,
            RectTransform reticleLayer)
        {
            primaryProviderBehaviour = primary;
            fallbackProviderBehaviour = fallback;
            eventCamera = camera;
            raycaster = graphicRaycaster;
            eventSystem = system;
            _reticleLayer = reticleLayer;

            _primary = primaryProviderBehaviour as IHandProvider;
            _fallback = fallbackProviderBehaviour as IHandProvider;

            _leftReticle = CreateReticle(
                "LeftReticle",
                HandFusionTheme.ReticleLeft
            );
            _rightReticle = CreateReticle(
                "RightReticle",
                HandFusionTheme.ReticleRight
            );
        }

        private void Awake()
        {
            _primary = primaryProviderBehaviour as IHandProvider;
            _fallback = fallbackProviderBehaviour as IHandProvider;
        }

        private void Update()
        {
            if (eventSystem == null || raycaster == null)
            {
                return;
            }

            var hasPrimary = _primary != null &&
                _primary.IsReady &&
                _primary.TryGetFrame(out var frame) &&
                frame != null &&
                frame.hands != null &&
                frame.hands.Length > 0;

            if (!hasPrimary)
            {
                frame = null;
                if (_fallback != null && _fallback.IsReady)
                {
                    _fallback.TryGetFrame(out frame);
                }
            }

            var hands = frame?.hands;
            VisibleHandCount = hands?.Length ?? 0;

            if (VisibleHandCount > 0)
            {
                _lastRealHandTime = Time.unscaledTime;
                ProcessHands(hands);
            }
            else
            {
                HideReticles();
                DebugState = "Sem mãos";

                if (
                    gazeFallback &&
                    Time.unscaledTime - _lastRealHandTime > 0.7f)
                {
                    ProcessGazeFallback();
                }
            }
        }

        private void ProcessHands(TrackedHand[] hands)
        {
            var leftVisible = false;
            var rightVisible = false;
            var stateTexts = new List<string>();

            foreach (var hand in hands)
            {
                if (hand == null || !hand.IsValid)
                {
                    continue;
                }

                var key = string.IsNullOrWhiteSpace(hand.handedness)
                    ? "Unknown"
                    : hand.handedness;

                var state = GetState(key);
                var indexTip = hand.landmarks[8];
                var thumbTip = hand.landmarks[4];
                var wrist = hand.landmarks[0];
                var middleMcp = hand.landmarks[9];

                var rawPointer = new Vector2(
                    Mathf.Clamp01(indexTip.x * 0.82f + thumbTip.x * 0.18f),
                    Mathf.Clamp01(indexTip.y * 0.82f + thumbTip.y * 0.18f)
                );

                state.filtered = FilterPointer(state, rawPointer);

                var palmSize = Mathf.Max(
                    0.001f,
                    Vector2.Distance(
                        new Vector2(wrist.x, wrist.y),
                        new Vector2(middleMcp.x, middleMcp.y)
                    )
                );
                var pinchRatio =
                    Vector2.Distance(
                        new Vector2(indexTip.x, indexTip.y),
                        new Vector2(thumbTip.x, thumbTip.y)
                    ) / palmSize;

                var isLeft = key.ToLowerInvariant().Contains("left");
                var reticle = isLeft ? _leftReticle : _rightReticle;

                if (isLeft)
                {
                    leftVisible = true;
                }
                else
                {
                    rightVisible = true;
                }

                ProcessPointer(
                    key,
                    state,
                    state.filtered,
                    pinchRatio,
                    reticle
                );

                stateTexts.Add(
                    $"{(isLeft ? "E" : "D")}: " +
                    (pinchRatio <= pinchCloseThreshold
                        ? "clicando"
                        : pinchRatio <= pinchReleaseThreshold
                            ? "mira pronta"
                            : "mirando")
                );
            }

            if (_leftReticle != null)
            {
                _leftReticle.gameObject.SetActive(leftVisible);
            }
            if (_rightReticle != null)
            {
                _rightReticle.gameObject.SetActive(rightVisible);
            }

            DebugState = stateTexts.Count > 0
                ? string.Join(" • ", stateTexts)
                : "Sem mãos";
        }

        private Vector2 FilterPointer(
            HandPointerState state,
            Vector2 raw)
        {
            if (!state.initialized)
            {
                state.initialized = true;
                state.filtered = raw;
                return raw;
            }

            var movement = Vector2.Distance(state.filtered, raw);
            var smoothing = movement > 0.055f
                ? Mathf.Max(0.25f, steadySmoothing - 0.28f)
                : steadySmoothing;

            state.filtered = Vector2.Lerp(
                raw,
                state.filtered,
                smoothing
            );
            return state.filtered;
        }

        private void ProcessPointer(
            string key,
            HandPointerState state,
            Vector2 normalized,
            float pinchRatio,
            RectTransform reticle)
        {
            var screenPosition = new Vector2(
                normalized.x * Screen.width,
                (1f - normalized.y) * Screen.height
            );

            if (reticle != null)
            {
                reticle.position = screenPosition;
                reticle.gameObject.SetActive(true);
            }

            var pointerData = state.eventData ??
                new PointerEventData(eventSystem)
                {
                    pointerId = key.GetHashCode()
                };

            state.eventData = pointerData;
            pointerData.position = screenPosition;
            pointerData.delta = Vector2.zero;
            pointerData.button = PointerEventData.InputButton.Left;

            _results.Clear();
            raycaster.Raycast(pointerData, _results);
            var target = _results.Count > 0
                ? _results[0].gameObject
                : null;

            if (target != state.hoverTarget)
            {
                if (state.hoverTarget != null)
                {
                    ExecuteEvents.Execute(
                        state.hoverTarget,
                        pointerData,
                        ExecuteEvents.pointerExitHandler
                    );
                }

                state.hoverTarget = target;
                state.hoverStartTime = Time.unscaledTime;

                if (target != null)
                {
                    ExecuteEvents.Execute(
                        target,
                        pointerData,
                        ExecuteEvents.pointerEnterHandler
                    );
                }
            }

            var armed = pinchRatio <= pinchReleaseThreshold;
            var closed = pinchRatio <= pinchCloseThreshold;

            SetReticleVisual(
                reticle,
                closed
                    ? HandFusionTheme.Danger
                    : armed
                        ? HandFusionTheme.Warning
                        : key.ToLowerInvariant().Contains("left")
                            ? HandFusionTheme.ReticleLeft
                            : HandFusionTheme.ReticleRight,
                closed ? 1.22f : armed ? 1.12f : 1f
            );

            var stableTarget =
                target != null &&
                Time.unscaledTime - state.hoverStartTime >=
                    targetHoldSeconds;

            if (
                closed &&
                !state.closedLatch &&
                stableTarget &&
                Time.unscaledTime - state.lastClickTime >=
                    clickCooldownSeconds)
            {
                state.closedLatch = true;
                state.lastClickTime = Time.unscaledTime;
                state.pressedTarget = target;

                ExecuteEvents.Execute(
                    target,
                    pointerData,
                    ExecuteEvents.pointerDownHandler
                );
                ExecuteEvents.Execute(
                    target,
                    pointerData,
                    ExecuteEvents.pointerClickHandler
                );
            }

            if (
                state.closedLatch &&
                pinchRatio >= pinchReleaseThreshold)
            {
                state.closedLatch = false;

                if (state.pressedTarget != null)
                {
                    ExecuteEvents.Execute(
                        state.pressedTarget,
                        pointerData,
                        ExecuteEvents.pointerUpHandler
                    );
                }

                state.pressedTarget = null;
            }
        }

        private void ProcessGazeFallback()
        {
            DebugState = "Mira central";

            var pointerData = new PointerEventData(eventSystem)
            {
                pointerId = -100,
                position = new Vector2(
                    Screen.width * 0.5f,
                    Screen.height * 0.5f
                ),
                button = PointerEventData.InputButton.Left
            };

            if (_leftReticle != null)
            {
                _leftReticle.gameObject.SetActive(true);
                _leftReticle.position = pointerData.position;
                SetReticleVisual(
                    _leftReticle,
                    HandFusionTheme.Primary,
                    1f
                );
            }

            if (_rightReticle != null)
            {
                _rightReticle.gameObject.SetActive(false);
            }

            var click =
                UnityEngine.InputSystem.Mouse.current?.leftButton.wasPressedThisFrame ==
                    true ||
                UnityEngine.InputSystem.Touchscreen.current?.primaryTouch
                    .press.wasPressedThisFrame == true ||
                UnityEngine.InputSystem.Keyboard.current?.spaceKey.wasPressedThisFrame ==
                    true;

            if (!click)
            {
                return;
            }

            _results.Clear();
            raycaster.Raycast(pointerData, _results);
            var target = _results.Count > 0
                ? _results[0].gameObject
                : null;

            if (target != null)
            {
                ExecuteEvents.Execute(
                    target,
                    pointerData,
                    ExecuteEvents.pointerClickHandler
                );
                _gazePressedTarget = target;
            }
        }

        private HandPointerState GetState(string key)
        {
            if (_states.TryGetValue(key, out var state))
            {
                return state;
            }

            state = new HandPointerState();
            _states[key] = state;
            return state;
        }

        private RectTransform CreateReticle(
            string objectName,
            Color color)
        {
            if (_reticleLayer == null)
            {
                return null;
            }

            var root = new GameObject(
                objectName,
                typeof(RectTransform),
                typeof(CanvasRenderer),
                typeof(Image)
            );

            var rect = root.GetComponent<RectTransform>();
            rect.SetParent(_reticleLayer, false);
            rect.sizeDelta = new Vector2(38f, 38f);

            var image = root.GetComponent<Image>();
            image.sprite = SpatialUIFactory.CreateCircleSprite(64);
            image.color = color;
            image.raycastTarget = false;

            root.SetActive(false);
            return rect;
        }

        private static void SetReticleVisual(
            RectTransform reticle,
            Color color,
            float scale)
        {
            if (reticle == null)
            {
                return;
            }

            var image = reticle.GetComponent<Image>();
            image.color = color;
            reticle.localScale = Vector3.one * scale;
        }

        private void HideReticles()
        {
            if (_leftReticle != null)
            {
                _leftReticle.gameObject.SetActive(false);
            }
            if (_rightReticle != null)
            {
                _rightReticle.gameObject.SetActive(false);
            }
        }

        public void SetSmoothing(float value)
        {
            steadySmoothing = Mathf.Clamp(value, 0f, 0.95f);
        }

        public void SetPinchThreshold(float value)
        {
            pinchCloseThreshold = Mathf.Clamp(value, 0.2f, 0.5f);
            pinchReleaseThreshold = Mathf.Max(
                pinchCloseThreshold + 0.15f,
                pinchReleaseThreshold
            );
        }
    }
}
