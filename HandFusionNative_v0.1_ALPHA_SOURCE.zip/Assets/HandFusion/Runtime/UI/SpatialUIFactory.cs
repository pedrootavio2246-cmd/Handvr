using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace HandFusion
{
    public static class SpatialUIFactory
    {
        private static Sprite _roundedSprite;
        private static Sprite _circleSprite;
        private static Font _font;

        public static Font Font
        {
            get
            {
                if (_font != null)
                {
                    return _font;
                }

                _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                if (_font == null)
                {
                    _font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                }

                return _font;
            }
        }

        public static Sprite CreateRoundedSprite(int size = 64, int radius = 14)
        {
            if (_roundedSprite != null)
            {
                return _roundedSprite;
            }

            var texture = new Texture2D(
                size,
                size,
                TextureFormat.RGBA32,
                false
            );
            texture.name = "HF_Rounded";
            texture.wrapMode = TextureWrapMode.Clamp;

            var colors = new Color32[size * size];
            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    var inside = InsideRoundedRect(
                        x,
                        y,
                        size,
                        size,
                        radius
                    );
                    colors[y * size + x] = inside
                        ? new Color32(255, 255, 255, 255)
                        : new Color32(255, 255, 255, 0);
                }
            }

            texture.SetPixels32(colors);
            texture.Apply(false, true);

            _roundedSprite = Sprite.Create(
                texture,
                new Rect(0, 0, size, size),
                new Vector2(0.5f, 0.5f),
                100f,
                0,
                SpriteMeshType.FullRect,
                new Vector4(radius, radius, radius, radius)
            );
            _roundedSprite.name = "HF_RoundedSprite";
            return _roundedSprite;
        }

        public static Sprite CreateCircleSprite(int size = 64)
        {
            if (_circleSprite != null)
            {
                return _circleSprite;
            }

            var texture = new Texture2D(
                size,
                size,
                TextureFormat.RGBA32,
                false
            );
            texture.name = "HF_Circle";

            var center = (size - 1) * 0.5f;
            var radius = center - 2f;
            var colors = new Color32[size * size];

            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    var distance = Vector2.Distance(
                        new Vector2(x, y),
                        new Vector2(center, center)
                    );
                    var alpha = distance <= radius
                        ? (byte)255
                        : (byte)0;
                    colors[y * size + x] =
                        new Color32(255, 255, 255, alpha);
                }
            }

            texture.SetPixels32(colors);
            texture.Apply(false, true);

            _circleSprite = Sprite.Create(
                texture,
                new Rect(0, 0, size, size),
                new Vector2(0.5f, 0.5f)
            );
            _circleSprite.name = "HF_CircleSprite";
            return _circleSprite;
        }

        private static bool InsideRoundedRect(
            int x,
            int y,
            int width,
            int height,
            int radius)
        {
            if (
                x >= radius &&
                x < width - radius ||
                y >= radius &&
                y < height - radius)
            {
                return true;
            }

            var cx = x < radius ? radius : width - radius - 1;
            var cy = y < radius ? radius : height - radius - 1;
            var dx = x - cx;
            var dy = y - cy;
            return dx * dx + dy * dy <= radius * radius;
        }

        public static RectTransform CreatePanel(
            Transform parent,
            string name,
            Color color,
            Vector2 size)
        {
            var objectValue = new GameObject(
                name,
                typeof(RectTransform),
                typeof(CanvasRenderer),
                typeof(Image)
            );
            var rect = objectValue.GetComponent<RectTransform>();
            rect.SetParent(parent, false);
            rect.sizeDelta = size;

            var image = objectValue.GetComponent<Image>();
            image.sprite = CreateRoundedSprite();
            image.type = Image.Type.Sliced;
            image.color = color;

            return rect;
        }

        public static Text CreateText(
            Transform parent,
            string name,
            string value,
            int fontSize,
            Color color,
            TextAnchor alignment = TextAnchor.MiddleCenter)
        {
            var objectValue = new GameObject(
                name,
                typeof(RectTransform),
                typeof(CanvasRenderer),
                typeof(Text)
            );
            var rect = objectValue.GetComponent<RectTransform>();
            rect.SetParent(parent, false);

            var text = objectValue.GetComponent<Text>();
            text.font = Font;
            text.text = value;
            text.fontSize = fontSize;
            text.color = color;
            text.alignment = alignment;
            text.supportRichText = true;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.raycastTarget = false;

            return text;
        }

        public static Button CreateButton(
            Transform parent,
            string name,
            string label,
            UnityAction onClick,
            Color? normal = null,
            Vector2? size = null)
        {
            var panel = CreatePanel(
                parent,
                name,
                normal ?? HandFusionTheme.SurfaceRaised,
                size ?? new Vector2(230f, 82f)
            );

            var button = panel.gameObject.AddComponent<Button>();
            var colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = HandFusionTheme.SurfaceHover;
            colors.pressedColor = HandFusionTheme.PrimaryPressed;
            colors.selectedColor = HandFusionTheme.SurfaceHover;
            colors.fadeDuration = 0.08f;
            button.colors = colors;
            button.targetGraphic = panel.GetComponent<Image>();

            var text = CreateText(
                panel,
                "Label",
                label,
                28,
                HandFusionTheme.Text
            );
            Stretch(text.rectTransform, 14f);

            if (onClick != null)
            {
                button.onClick.AddListener(onClick);
            }

            return button;
        }

        public static InputField CreateInputField(
            Transform parent,
            string name,
            string placeholder,
            Vector2 size)
        {
            var panel = CreatePanel(
                parent,
                name,
                HandFusionTheme.Background,
                size
            );

            var input = panel.gameObject.AddComponent<InputField>();
            input.targetGraphic = panel.GetComponent<Image>();

            var text = CreateText(
                panel,
                "Text",
                "",
                29,
                HandFusionTheme.Text,
                TextAnchor.MiddleLeft
            );
            Stretch(text.rectTransform, 22f);
            input.textComponent = text;

            var placeholderText = CreateText(
                panel,
                "Placeholder",
                placeholder,
                27,
                HandFusionTheme.TextMuted,
                TextAnchor.MiddleLeft
            );
            Stretch(placeholderText.rectTransform, 22f);
            input.placeholder = placeholderText;

            return input;
        }

        public static void Stretch(RectTransform rect, float padding = 0f)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(padding, padding);
            rect.offsetMax = new Vector2(-padding, -padding);
        }

        public static VerticalLayoutGroup AddVerticalLayout(
            GameObject gameObject,
            float spacing = 14f,
            int padding = 18)
        {
            var layout = gameObject.AddComponent<VerticalLayoutGroup>();
            layout.spacing = spacing;
            layout.padding = new RectOffset(
                padding,
                padding,
                padding,
                padding
            );
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = false;
            return layout;
        }

        public static HorizontalLayoutGroup AddHorizontalLayout(
            GameObject gameObject,
            float spacing = 14f,
            int padding = 0)
        {
            var layout = gameObject.AddComponent<HorizontalLayoutGroup>();
            layout.spacing = spacing;
            layout.padding = new RectOffset(
                padding,
                padding,
                padding,
                padding
            );
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = false;
            return layout;
        }

        public static GridLayoutGroup AddGridLayout(
            GameObject gameObject,
            Vector2 cell,
            Vector2 spacing,
            int columns)
        {
            var layout = gameObject.AddComponent<GridLayoutGroup>();
            layout.cellSize = cell;
            layout.spacing = spacing;
            layout.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            layout.constraintCount = columns;
            layout.childAlignment = TextAnchor.UpperCenter;
            return layout;
        }

        public static LayoutElement SetLayout(
            GameObject gameObject,
            float width = -1f,
            float height = -1f,
            float flexibleWidth = 0f,
            float flexibleHeight = 0f)
        {
            var layout = gameObject.GetComponent<LayoutElement>() ??
                gameObject.AddComponent<LayoutElement>();

            if (width >= 0f)
            {
                layout.preferredWidth = width;
            }
            if (height >= 0f)
            {
                layout.preferredHeight = height;
            }

            layout.flexibleWidth = flexibleWidth;
            layout.flexibleHeight = flexibleHeight;
            return layout;
        }
    }
}
