using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace HandFusion
{
    public sealed class SpatialWindow :
        MonoBehaviour,
        IBeginDragHandler,
        IDragHandler,
        IPointerDownHandler
    {
        private RectTransform _rect;
        private RectTransform _desktop;
        private Vector2 _dragOffset;

        public string AppId { get; private set; }
        public RectTransform Content { get; private set; }

        public static SpatialWindow Create(
            RectTransform desktop,
            string appId,
            string title,
            Vector2 size,
            System.Action onClose)
        {
            var root = SpatialUIFactory.CreatePanel(
                desktop,
                $"Window_{appId}",
                HandFusionTheme.Surface,
                size
            );
            root.anchorMin = root.anchorMax = new Vector2(0.5f, 0.5f);
            root.anchoredPosition = new Vector2(
                Random.Range(-120f, 120f),
                Random.Range(-60f, 80f)
            );

            var window = root.gameObject.AddComponent<SpatialWindow>();
            window._rect = root;
            window._desktop = desktop;
            window.AppId = appId;

            var shadow = root.gameObject.AddComponent<Shadow>();
            shadow.effectColor = new Color(0f, 0f, 0f, 0.36f);
            shadow.effectDistance = new Vector2(12f, -14f);

            var titleBar = SpatialUIFactory.CreatePanel(
                root,
                "TitleBar",
                HandFusionTheme.SurfaceRaised,
                new Vector2(size.x - 18f, 84f)
            );
            titleBar.anchorMin = new Vector2(0.5f, 1f);
            titleBar.anchorMax = new Vector2(0.5f, 1f);
            titleBar.pivot = new Vector2(0.5f, 1f);
            titleBar.anchoredPosition = new Vector2(0f, -9f);

            var titleText = SpatialUIFactory.CreateText(
                titleBar,
                "Title",
                title,
                31,
                HandFusionTheme.Text,
                TextAnchor.MiddleLeft
            );
            titleText.rectTransform.anchorMin = new Vector2(0f, 0f);
            titleText.rectTransform.anchorMax = new Vector2(1f, 1f);
            titleText.rectTransform.offsetMin = new Vector2(30f, 0f);
            titleText.rectTransform.offsetMax = new Vector2(-110f, 0f);

            var close = SpatialUIFactory.CreateButton(
                titleBar,
                "Close",
                "×",
                () => onClose?.Invoke(),
                HandFusionTheme.Danger,
                new Vector2(68f, 58f)
            );
            var closeRect = close.GetComponent<RectTransform>();
            closeRect.anchorMin = closeRect.anchorMax = new Vector2(1f, 0.5f);
            closeRect.anchoredPosition = new Vector2(-40f, 0f);

            var dragSurface = titleBar.gameObject.AddComponent<WindowDragSurface>();
            dragSurface.Window = window;

            var content = SpatialUIFactory.CreatePanel(
                root,
                "Content",
                new Color(0f, 0f, 0f, 0f),
                new Vector2(size.x - 36f, size.y - 122f)
            );
            content.anchorMin = new Vector2(0.5f, 0f);
            content.anchorMax = new Vector2(0.5f, 0f);
            content.pivot = new Vector2(0.5f, 0f);
            content.anchoredPosition = new Vector2(0f, 18f);
            content.GetComponent<Image>().raycastTarget = false;

            window.Content = content;
            return window;
        }

        public void BringToFront()
        {
            transform.SetAsLastSibling();
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            BringToFront();
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            BringToFront();

            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                _desktop,
                eventData.position,
                eventData.pressEventCamera,
                out var localPoint
            );
            _dragOffset = _rect.anchoredPosition - localPoint;
        }

        public void OnDrag(PointerEventData eventData)
        {
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                _desktop,
                eventData.position,
                eventData.pressEventCamera,
                out var localPoint
            );

            var target = localPoint + _dragOffset;
            var half = _rect.sizeDelta * 0.5f;
            var desktopHalf = _desktop.rect.size * 0.5f;

            target.x = Mathf.Clamp(
                target.x,
                -desktopHalf.x + half.x * 0.45f,
                desktopHalf.x - half.x * 0.45f
            );
            target.y = Mathf.Clamp(
                target.y,
                -desktopHalf.y + half.y * 0.35f,
                desktopHalf.y - half.y * 0.35f
            );

            _rect.anchoredPosition = target;
        }
    }

    public sealed class WindowDragSurface :
        MonoBehaviour,
        IBeginDragHandler,
        IDragHandler,
        IPointerDownHandler
    {
        public SpatialWindow Window { get; set; }

        public void OnPointerDown(PointerEventData eventData)
        {
            Window?.OnPointerDown(eventData);
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            Window?.OnBeginDrag(eventData);
        }

        public void OnDrag(PointerEventData eventData)
        {
            Window?.OnDrag(eventData);
        }
    }
}
