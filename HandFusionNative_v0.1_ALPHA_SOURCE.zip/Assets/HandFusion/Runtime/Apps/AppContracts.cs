using System;
using System.Collections.Generic;
using UnityEngine;

namespace HandFusion.Apps
{
    public interface IHandFusionApp
    {
        string Id { get; }
        string DisplayName { get; }
        string Icon { get; }
        Vector2 PreferredSize { get; }
        void Build(RectTransform content, HandFusionServices services);
    }

    public sealed class HandFusionServices
    {
        public HandFusionBootstrap Bootstrap { get; init; }
        public HandFusionPerformance Performance { get; init; }
        public HandFusion.Input.HandInputRouter InputRouter { get; init; }
        public Action<string> OpenApp { get; init; }
        public Action<string> ShowToast { get; init; }
        public Func<IReadOnlyList<IHandFusionApp>> GetApps { get; init; }
    }
}
