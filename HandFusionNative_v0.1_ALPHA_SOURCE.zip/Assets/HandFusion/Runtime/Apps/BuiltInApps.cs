using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using UnityEngine.Video;

namespace HandFusion.Apps
{
    public sealed class HomeApp : IHandFusionApp
    {
        public string Id => "home";
        public string DisplayName => "Início";
        public string Icon => "⌂";
        public Vector2 PreferredSize => new Vector2(1040f, 600f);

        public void Build(RectTransform content, HandFusionServices services)
        {
            var title = SpatialUIFactory.CreateText(
                content,
                "Title",
                "HandFusion Native",
                56,
                HandFusionTheme.Text,
                TextAnchor.UpperLeft
            );
            title.rectTransform.anchorMin = new Vector2(0f, 1f);
            title.rectTransform.anchorMax = new Vector2(1f, 1f);
            title.rectTransform.pivot = new Vector2(0.5f, 1f);
            title.rectTransform.sizeDelta = new Vector2(0f, 90f);
            title.rectTransform.anchoredPosition = new Vector2(24f, -20f);

            var subtitle = SpatialUIFactory.CreateText(
                content,
                "Subtitle",
                "Painéis espaciais, jogos, mídia e ferramentas para VR Box.",
                28,
                HandFusionTheme.TextMuted,
                TextAnchor.UpperLeft
            );
            subtitle.rectTransform.anchorMin = new Vector2(0f, 1f);
            subtitle.rectTransform.anchorMax = new Vector2(1f, 1f);
            subtitle.rectTransform.pivot = new Vector2(0.5f, 1f);
            subtitle.rectTransform.sizeDelta = new Vector2(0f, 65f);
            subtitle.rectTransform.anchoredPosition = new Vector2(24f, -105f);

            var grid = SpatialUIFactory.CreatePanel(
                content,
                "QuickGrid",
                new Color(0f, 0f, 0f, 0f),
                new Vector2(960f, 360f)
            );
            grid.anchorMin = grid.anchorMax = new Vector2(0.5f, 0.5f);
            grid.anchoredPosition = new Vector2(0f, -55f);
            grid.GetComponent<Image>().raycastTarget = false;
            SpatialUIFactory.AddGridLayout(
                grid.gameObject,
                new Vector2(292f, 145f),
                new Vector2(24f, 24f),
                3
            );

            var cards = new[]
            {
                ("browser", "◎  Navegador"),
                ("cinema", "▶  Cinema"),
                ("calculator", "＋  Calculadora"),
                ("game", "◆  Pinch Arena"),
                ("store", "▦  Fusion Store"),
                ("tester", "✓  Central Tester")
            };

            foreach (var (id, label) in cards)
            {
                SpatialUIFactory.CreateButton(
                    grid,
                    $"Quick_{id}",
                    label,
                    () => services.OpenApp(id),
                    HandFusionTheme.SurfaceRaised,
                    new Vector2(292f, 145f)
                );
            }
        }
    }

    public sealed class BrowserApp : IHandFusionApp
    {
        public string Id => "browser";
        public string DisplayName => "Fusion Browser";
        public string Icon => "◎";
        public Vector2 PreferredSize => new Vector2(1120f, 690f);

        public void Build(RectTransform content, HandFusionServices services)
        {
            var input = SpatialUIFactory.CreateInputField(
                content,
                "Search",
                "Pesquise no Google ou cole um endereço",
                new Vector2(760f, 86f)
            );
            var inputRect = input.GetComponent<RectTransform>();
            inputRect.anchorMin = inputRect.anchorMax = new Vector2(0.5f, 1f);
            inputRect.anchoredPosition = new Vector2(-95f, -70f);

            var search = SpatialUIFactory.CreateButton(
                content,
                "SearchButton",
                "Pesquisar",
                () =>
                {
                    var value = input.text.Trim();
                    if (string.IsNullOrEmpty(value))
                    {
                        services.ShowToast("Digite algo para pesquisar.");
                        return;
                    }

                    var url = value.StartsWith("http", StringComparison.OrdinalIgnoreCase)
                        ? value
                        : $"https://www.google.com/search?q={UnityWebRequest.EscapeURL(value)}";
                    Application.OpenURL(url);
                },
                HandFusionTheme.Primary,
                new Vector2(220f, 86f)
            );
            var searchRect = search.GetComponent<RectTransform>();
            searchRect.anchorMin = searchRect.anchorMax = new Vector2(1f, 1f);
            searchRect.anchoredPosition = new Vector2(-125f, -70f);

            var info = SpatialUIFactory.CreatePanel(
                content,
                "BrowserSurface",
                HandFusionTheme.Background,
                new Vector2(1045f, 455f)
            );
            info.anchorMin = info.anchorMax = new Vector2(0.5f, 0.5f);
            info.anchoredPosition = new Vector2(0f, -60f);

            var message = SpatialUIFactory.CreateText(
                info,
                "Message",
                "<b>Fusion Browser Alpha</b>\n\n" +
                "A pesquisa abre o navegador do Android enquanto o WebView espacial " +
                "é integrado. O sistema de janelas, teclado e histórico já está " +
                "preparado para receber o módulo nativo.",
                31,
                HandFusionTheme.TextMuted
            );
            SpatialUIFactory.Stretch(message.rectTransform, 80f);

            var keyboard = new VirtualKeyboardController();
            keyboard.Build(
                content,
                input,
                new Vector2(1045f, 330f),
                new Vector2(0f, -185f)
            );
        }
    }

    public sealed class CalculatorApp : IHandFusionApp
    {
        public string Id => "calculator";
        public string DisplayName => "Calculadora";
        public string Icon => "＋";
        public Vector2 PreferredSize => new Vector2(610f, 720f);

        private string _expression = "";
        private Text _display;

        public void Build(RectTransform content, HandFusionServices services)
        {
            _display = SpatialUIFactory.CreateText(
                content,
                "Display",
                "0",
                48,
                HandFusionTheme.Text,
                TextAnchor.MiddleRight
            );
            var displayPanel = SpatialUIFactory.CreatePanel(
                content,
                "DisplayPanel",
                HandFusionTheme.Background,
                new Vector2(535f, 120f)
            );
            displayPanel.anchorMin = displayPanel.anchorMax =
                new Vector2(0.5f, 1f);
            displayPanel.anchoredPosition = new Vector2(0f, -78f);
            _display.rectTransform.SetParent(displayPanel, false);
            SpatialUIFactory.Stretch(_display.rectTransform, 30f);

            var grid = SpatialUIFactory.CreatePanel(
                content,
                "Grid",
                new Color(0f, 0f, 0f, 0f),
                new Vector2(535f, 465f)
            );
            grid.anchorMin = grid.anchorMax = new Vector2(0.5f, 0.5f);
            grid.anchoredPosition = new Vector2(0f, -52f);
            grid.GetComponent<Image>().raycastTarget = false;
            SpatialUIFactory.AddGridLayout(
                grid.gameObject,
                new Vector2(120f, 92f),
                new Vector2(18f, 18f),
                4
            );

            var keys = new[]
            {
                "C", "⌫", "(", ")",
                "7", "8", "9", "÷",
                "4", "5", "6", "×",
                "1", "2", "3", "−",
                "0", ".", "=", "+"
            };

            foreach (var key in keys)
            {
                SpatialUIFactory.CreateButton(
                    grid,
                    $"Key_{key}",
                    key,
                    () => Press(key),
                    key == "="
                        ? HandFusionTheme.Primary
                        : HandFusionTheme.SurfaceRaised,
                    new Vector2(120f, 92f)
                );
            }
        }

        private void Press(string key)
        {
            if (key == "C")
            {
                _expression = "";
            }
            else if (key == "⌫")
            {
                if (_expression.Length > 0)
                {
                    _expression =
                        _expression.Substring(0, _expression.Length - 1);
                }
            }
            else if (key == "=")
            {
                _expression = Evaluate(_expression);
            }
            else
            {
                _expression += key switch
                {
                    "÷" => "/",
                    "×" => "*",
                    "−" => "-",
                    _ => key
                };
            }

            _display.text = string.IsNullOrEmpty(_expression)
                ? "0"
                : _expression;
        }

        private static string Evaluate(string expression)
        {
            try
            {
                var table = new System.Data.DataTable();
                var value = table.Compute(expression, string.Empty);
                return Convert.ToString(
                    value,
                    System.Globalization.CultureInfo.InvariantCulture
                );
            }
            catch
            {
                return "Erro";
            }
        }
    }

    public sealed class CinemaApp : IHandFusionApp
    {
        public string Id => "cinema";
        public string DisplayName => "Fusion Cinema";
        public string Icon => "▶";
        public Vector2 PreferredSize => new Vector2(1120f, 720f);

        public void Build(RectTransform content, HandFusionServices services)
        {
            var input = SpatialUIFactory.CreateInputField(
                content,
                "VideoUrl",
                "URL direta de vídeo MP4",
                new Vector2(730f, 76f)
            );
            var inputRect = input.GetComponent<RectTransform>();
            inputRect.anchorMin = inputRect.anchorMax = new Vector2(0.5f, 1f);
            inputRect.anchoredPosition = new Vector2(-105f, -62f);

            var screenPanel = SpatialUIFactory.CreatePanel(
                content,
                "Screen",
                Color.black,
                new Vector2(1035f, 470f)
            );
            screenPanel.anchorMin = screenPanel.anchorMax =
                new Vector2(0.5f, 0.5f);
            screenPanel.anchoredPosition = new Vector2(0f, -50f);

            var rawImageObject = new GameObject(
                "VideoImage",
                typeof(RectTransform),
                typeof(CanvasRenderer),
                typeof(RawImage)
            );
            var rawRect =
                rawImageObject.GetComponent<RectTransform>();
            rawRect.SetParent(screenPanel, false);
            SpatialUIFactory.Stretch(rawRect, 15f);
            var rawImage = rawImageObject.GetComponent<RawImage>();
            rawImage.color = Color.white;
            rawImage.raycastTarget = false;

            var player = screenPanel.gameObject.AddComponent<VideoPlayer>();
            player.playOnAwake = false;
            player.audioOutputMode = VideoAudioOutputMode.Direct;
            player.renderMode = VideoRenderMode.RenderTexture;

            var texture = new RenderTexture(
                1280,
                720,
                0,
                RenderTextureFormat.ARGB32
            );
            texture.name = "HandFusionCinema";
            texture.Create();
            player.targetTexture = texture;
            rawImage.texture = texture;

            var play = SpatialUIFactory.CreateButton(
                content,
                "Play",
                "Carregar e reproduzir",
                () =>
                {
                    var url = input.text.Trim();
                    if (string.IsNullOrEmpty(url))
                    {
                        services.ShowToast("Cole uma URL direta de vídeo.");
                        return;
                    }

                    player.url = url;
                    player.Prepare();
                    player.prepareCompleted += prepared =>
                    {
                        prepared.Play();
                        services.ShowToast("Vídeo iniciado.");
                    };
                },
                HandFusionTheme.Primary,
                new Vector2(290f, 76f)
            );
            var playRect = play.GetComponent<RectTransform>();
            playRect.anchorMin = playRect.anchorMax = new Vector2(1f, 1f);
            playRect.anchoredPosition = new Vector2(-160f, -62f);

            var pause = SpatialUIFactory.CreateButton(
                content,
                "Pause",
                "Pausar / continuar",
                () =>
                {
                    if (player.isPlaying)
                    {
                        player.Pause();
                    }
                    else
                    {
                        player.Play();
                    }
                },
                HandFusionTheme.SurfaceRaised,
                new Vector2(270f, 70f)
            );
            var pauseRect = pause.GetComponent<RectTransform>();
            pauseRect.anchorMin = pauseRect.anchorMax =
                new Vector2(0.5f, 0f);
            pauseRect.anchoredPosition = new Vector2(0f, 48f);
        }
    }

    public sealed class TargetPracticeApp : IHandFusionApp
    {
        public string Id => "game";
        public string DisplayName => "Pinch Arena";
        public string Icon => "◆";
        public Vector2 PreferredSize => new Vector2(980f, 650f);

        private Text _scoreText;
        private Button _target;
        private RectTransform _arena;
        private int _score;
        private float _startTime;

        public void Build(RectTransform content, HandFusionServices services)
        {
            _score = 0;
            _startTime = Time.unscaledTime;

            _scoreText = SpatialUIFactory.CreateText(
                content,
                "Score",
                "Pontos: 0",
                34,
                HandFusionTheme.Text,
                TextAnchor.MiddleLeft
            );
            _scoreText.rectTransform.anchorMin = new Vector2(0f, 1f);
            _scoreText.rectTransform.anchorMax = new Vector2(1f, 1f);
            _scoreText.rectTransform.sizeDelta = new Vector2(0f, 70f);
            _scoreText.rectTransform.anchoredPosition =
                new Vector2(30f, -32f);

            _arena = SpatialUIFactory.CreatePanel(
                content,
                "Arena",
                HandFusionTheme.Background,
                new Vector2(900f, 505f)
            );
            _arena.anchorMin = _arena.anchorMax = new Vector2(0.5f, 0.5f);
            _arena.anchoredPosition = new Vector2(0f, -35f);

            _target = SpatialUIFactory.CreateButton(
                _arena,
                "Target",
                "◆",
                Hit,
                HandFusionTheme.Primary,
                new Vector2(125f, 125f)
            );
            MoveTarget();
        }

        private void Hit()
        {
            _score++;
            var elapsed = Mathf.Max(0.1f, Time.unscaledTime - _startTime);
            var accuracy = _score / elapsed;
            _scoreText.text =
                $"Pontos: {_score}   Ritmo: {accuracy:0.0}/s";
            MoveTarget();
        }

        private void MoveTarget()
        {
            if (_target == null || _arena == null)
            {
                return;
            }

            var rect = _target.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = new Vector2(
                UnityEngine.Random.Range(-350f, 350f),
                UnityEngine.Random.Range(-175f, 175f)
            );
        }
    }

    [Serializable]
    public sealed class AppCatalog
    {
        public CatalogEntry[] apps;
    }

    [Serializable]
    public sealed class CatalogEntry
    {
        public string id;
        public string name;
        public string version;
        public string author;
        public string description;
        public string type;
        public string[] permissions;
    }

    public sealed class StoreApp : IHandFusionApp
    {
        public string Id => "store";
        public string DisplayName => "Fusion Store";
        public string Icon => "▦";
        public Vector2 PreferredSize => new Vector2(1040f, 680f);

        public void Build(RectTransform content, HandFusionServices services)
        {
            var header = SpatialUIFactory.CreateText(
                content,
                "Header",
                "Fusion Store • canal Alpha",
                38,
                HandFusionTheme.Text,
                TextAnchor.MiddleLeft
            );
            header.rectTransform.anchorMin = new Vector2(0f, 1f);
            header.rectTransform.anchorMax = new Vector2(1f, 1f);
            header.rectTransform.sizeDelta = new Vector2(0f, 74f);
            header.rectTransform.anchoredPosition = new Vector2(28f, -35f);

            var list = SpatialUIFactory.CreatePanel(
                content,
                "List",
                new Color(0f, 0f, 0f, 0f),
                new Vector2(960f, 510f)
            );
            list.anchorMin = list.anchorMax = new Vector2(0.5f, 0.5f);
            list.anchoredPosition = new Vector2(0f, -35f);
            list.GetComponent<Image>().raycastTarget = false;
            SpatialUIFactory.AddVerticalLayout(
                list.gameObject,
                14f,
                6
            );

            services.Bootstrap.StartCoroutine(
                LoadCatalog(list, services)
            );
        }

        private static IEnumerator LoadCatalog(
            RectTransform list,
            HandFusionServices services)
        {
            var path = Path.Combine(
                Application.streamingAssetsPath,
                "AppCatalog.json"
            );

            string json;

            if (path.Contains("://"))
            {
                using var request = UnityWebRequest.Get(path);
                yield return request.SendWebRequest();

                if (request.result != UnityWebRequest.Result.Success)
                {
                    services.ShowToast("Não foi possível abrir o catálogo.");
                    yield break;
                }

                json = request.downloadHandler.text;
            }
            else
            {
                json = File.Exists(path)
                    ? File.ReadAllText(path)
                    : string.Empty;
            }

            var catalog = string.IsNullOrEmpty(json)
                ? null
                : JsonUtility.FromJson<AppCatalog>(json);

            if (catalog?.apps == null)
            {
                yield break;
            }

            foreach (var entry in catalog.apps)
            {
                var card = SpatialUIFactory.CreatePanel(
                    list,
                    $"App_{entry.id}",
                    HandFusionTheme.SurfaceRaised,
                    new Vector2(930f, 138f)
                );
                SpatialUIFactory.SetLayout(card.gameObject, -1f, 138f);

                var title = SpatialUIFactory.CreateText(
                    card,
                    "Name",
                    $"{entry.name}  <size=22>v{entry.version}</size>",
                    31,
                    HandFusionTheme.Text,
                    TextAnchor.UpperLeft
                );
                title.rectTransform.anchorMin = new Vector2(0f, 0.45f);
                title.rectTransform.anchorMax = new Vector2(0.73f, 1f);
                title.rectTransform.offsetMin = new Vector2(26f, 0f);
                title.rectTransform.offsetMax = Vector2.zero;

                var description = SpatialUIFactory.CreateText(
                    card,
                    "Description",
                    entry.description,
                    23,
                    HandFusionTheme.TextMuted,
                    TextAnchor.UpperLeft
                );
                description.rectTransform.anchorMin = new Vector2(0f, 0f);
                description.rectTransform.anchorMax = new Vector2(0.73f, 0.58f);
                description.rectTransform.offsetMin = new Vector2(26f, 8f);
                description.rectTransform.offsetMax = Vector2.zero;

                var install = SpatialUIFactory.CreateButton(
                    card,
                    "Install",
                    "Instalar",
                    () => services.ShowToast(
                        $"{entry.name} adicionado ao catálogo local."
                    ),
                    HandFusionTheme.Primary,
                    new Vector2(205f, 76f)
                );
                var installRect = install.GetComponent<RectTransform>();
                installRect.anchorMin = installRect.anchorMax =
                    new Vector2(1f, 0.5f);
                installRect.anchoredPosition = new Vector2(-120f, 0f);
            }
        }
    }

    public sealed class SettingsApp : IHandFusionApp
    {
        public string Id => "settings";
        public string DisplayName => "Configurações";
        public string Icon => "⚙";
        public Vector2 PreferredSize => new Vector2(840f, 620f);

        public void Build(RectTransform content, HandFusionServices services)
        {
            var body = SpatialUIFactory.CreatePanel(
                content,
                "Body",
                new Color(0f, 0f, 0f, 0f),
                new Vector2(760f, 500f)
            );
            body.anchorMin = body.anchorMax = new Vector2(0.5f, 0.5f);
            body.anchoredPosition = Vector2.zero;
            body.GetComponent<Image>().raycastTarget = false;
            SpatialUIFactory.AddVerticalLayout(
                body.gameObject,
                18f,
                10
            );

            var title = SpatialUIFactory.CreateText(
                body,
                "Title",
                "Perfil de desempenho",
                37,
                HandFusionTheme.Text,
                TextAnchor.MiddleLeft
            );
            SpatialUIFactory.SetLayout(title.gameObject, -1f, 70f);

            foreach (HandFusionQuality quality in
                Enum.GetValues(typeof(HandFusionQuality)))
            {
                var localQuality = quality;
                SpatialUIFactory.CreateButton(
                    body,
                    $"Quality_{quality}",
                    quality switch
                    {
                        HandFusionQuality.Battery =>
                            "Economia • celulares fracos",
                        HandFusionQuality.Balanced =>
                            "Equilibrado • recomendado",
                        _ => "Qualidade • celulares fortes"
                    },
                    () =>
                    {
                        services.Performance.Apply(localQuality);
                        services.ShowToast(
                            $"Perfil alterado para {localQuality}."
                        );
                    },
                    quality == services.Performance.Current
                        ? HandFusionTheme.Primary
                        : HandFusionTheme.SurfaceRaised,
                    new Vector2(720f, 96f)
                );
            }

            SpatialUIFactory.CreateButton(
                body,
                "Recenter",
                "Recentralizar interface",
                services.Bootstrap.RecenterDesktop,
                HandFusionTheme.Secondary,
                new Vector2(720f, 96f)
            );
        }
    }

    [Serializable]
    public sealed class TesterReport
    {
        public string createdAt;
        public string deviceModel;
        public string operatingSystem;
        public string graphicsDevice;
        public int memoryMb;
        public string quality;
        public string notes;
        public float averageFps;
    }

    public sealed class TesterApp : IHandFusionApp
    {
        public string Id => "tester";
        public string DisplayName => "Central Tester";
        public string Icon => "✓";
        public Vector2 PreferredSize => new Vector2(970f, 680f);

        public void Build(RectTransform content, HandFusionServices services)
        {
            var details = SpatialUIFactory.CreateText(
                content,
                "Details",
                $"Dispositivo: {SystemInfo.deviceModel}\n" +
                $"Sistema: {SystemInfo.operatingSystem}\n" +
                $"GPU: {SystemInfo.graphicsDeviceName}\n" +
                $"Memória: {SystemInfo.systemMemorySize} MB\n" +
                $"Perfil: {services.Performance.Current}",
                27,
                HandFusionTheme.TextMuted,
                TextAnchor.UpperLeft
            );
            details.rectTransform.anchorMin = new Vector2(0f, 1f);
            details.rectTransform.anchorMax = new Vector2(1f, 1f);
            details.rectTransform.pivot = new Vector2(0.5f, 1f);
            details.rectTransform.sizeDelta = new Vector2(0f, 230f);
            details.rectTransform.anchoredPosition = new Vector2(35f, -30f);

            var notes = SpatialUIFactory.CreateInputField(
                content,
                "Notes",
                "Escreva o bug, o que travou e o que estava fazendo...",
                new Vector2(875f, 225f)
            );
            var notesRect = notes.GetComponent<RectTransform>();
            notesRect.anchorMin = notesRect.anchorMax = new Vector2(0.5f, 0.5f);
            notesRect.anchoredPosition = new Vector2(0f, -55f);
            notes.lineType = InputField.LineType.MultiLineNewline;

            var export = SpatialUIFactory.CreateButton(
                content,
                "Export",
                "Salvar relatório do tester",
                () =>
                {
                    var report = new TesterReport
                    {
                        createdAt = DateTime.UtcNow.ToString("O"),
                        deviceModel = SystemInfo.deviceModel,
                        operatingSystem = SystemInfo.operatingSystem,
                        graphicsDevice = SystemInfo.graphicsDeviceName,
                        memoryMb = SystemInfo.systemMemorySize,
                        quality = services.Performance.Current.ToString(),
                        notes = notes.text,
                        averageFps = services.Bootstrap.AverageFps
                    };

                    var folder = Path.Combine(
                        Application.persistentDataPath,
                        "TesterReports"
                    );
                    Directory.CreateDirectory(folder);

                    var file = Path.Combine(
                        folder,
                        $"handfusion-{DateTime.Now:yyyyMMdd-HHmmss}.json"
                    );
                    File.WriteAllText(
                        file,
                        JsonUtility.ToJson(report, true),
                        Encoding.UTF8
                    );

                    services.ShowToast($"Relatório salvo em:\n{file}");
                },
                HandFusionTheme.Primary,
                new Vector2(430f, 92f)
            );
            var exportRect = export.GetComponent<RectTransform>();
            exportRect.anchorMin = exportRect.anchorMax =
                new Vector2(0.5f, 0f);
            exportRect.anchoredPosition = new Vector2(0f, 65f);
        }
    }

    public sealed class VirtualKeyboardController
    {
        private static readonly string[][] Rows =
        {
            new[] {"Q","W","E","R","T","Y","U","I","O","P"},
            new[] {"A","S","D","F","G","H","J","K","L"},
            new[] {"Z","X","C","V","B","N","M","⌫"},
            new[] {"FECHAR","ESPAÇO","BUSCAR"}
        };

        private RectTransform _keyboard;
        private InputField _input;

        public void Build(
            RectTransform parent,
            InputField input,
            Vector2 size,
            Vector2 position)
        {
            _input = input;
            _keyboard = SpatialUIFactory.CreatePanel(
                parent,
                "VirtualKeyboard",
                HandFusionTheme.SurfaceRaised,
                size
            );
            _keyboard.anchorMin = _keyboard.anchorMax =
                new Vector2(0.5f, 0f);
            _keyboard.anchoredPosition = position;
            _keyboard.gameObject.SetActive(false);

            var rowsContainer = SpatialUIFactory.CreatePanel(
                _keyboard,
                "Rows",
                new Color(0f, 0f, 0f, 0f),
                size - new Vector2(36f, 32f)
            );
            SpatialUIFactory.Stretch(rowsContainer, 16f);
            rowsContainer.GetComponent<Image>().raycastTarget = false;
            SpatialUIFactory.AddVerticalLayout(
                rowsContainer.gameObject,
                10f,
                0
            );

            foreach (var row in Rows)
            {
                var rowPanel = SpatialUIFactory.CreatePanel(
                    rowsContainer,
                    "Row",
                    new Color(0f, 0f, 0f, 0f),
                    new Vector2(size.x - 60f, 63f)
                );
                rowPanel.GetComponent<Image>().raycastTarget = false;
                SpatialUIFactory.SetLayout(rowPanel.gameObject, -1f, 63f);
                SpatialUIFactory.AddHorizontalLayout(
                    rowPanel.gameObject,
                    8f,
                    0
                );

                foreach (var key in row)
                {
                    var localKey = key;
                    var button = SpatialUIFactory.CreateButton(
                        rowPanel,
                        $"Key_{key}",
                        key,
                        () => Press(localKey),
                        key == "BUSCAR"
                            ? HandFusionTheme.Primary
                            : HandFusionTheme.Background,
                        new Vector2(80f, 63f)
                    );
                    SpatialUIFactory.SetLayout(
                        button.gameObject,
                        key == "ESPAÇO"
                            ? 280f
                            : key.Length > 2
                                ? 150f
                                : 76f,
                        63f,
                        key.Length == 1 ? 1f : 0f
                    );
                }
            }

            input.onSelect.AddListener(_ => _keyboard.gameObject.SetActive(true));
        }

        private void Press(string key)
        {
            switch (key)
            {
                case "⌫":
                    if (_input.text.Length > 0)
                    {
                        _input.text = _input.text.Substring(
                            0,
                            _input.text.Length - 1
                        );
                    }
                    break;

                case "ESPAÇO":
                    _input.text += " ";
                    break;

                case "FECHAR":
                    _keyboard.gameObject.SetActive(false);
                    break;

                case "BUSCAR":
                    _input.onEndEdit.Invoke(_input.text);
                    break;

                default:
                    _input.text += key.ToLowerInvariant();
                    break;
            }

            _input.caretPosition = _input.text.Length;
        }
    }
}
