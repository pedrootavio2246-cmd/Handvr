using System;
using UnityEngine;

namespace HandFusion
{
    public enum HandFusionQuality
    {
        Battery,
        Balanced,
        Quality
    }

    public sealed class HandFusionPerformance : MonoBehaviour
    {
        public HandFusionQuality Current { get; private set; } =
            HandFusionQuality.Balanced;

        public event Action<HandFusionQuality> Changed;

        public void Apply(HandFusionQuality quality)
        {
            Current = quality;

            switch (quality)
            {
                case HandFusionQuality.Battery:
                    Application.targetFrameRate = 45;
                    QualitySettings.vSyncCount = 0;
                    QualitySettings.shadows = ShadowQuality.Disable;
                    QualitySettings.antiAliasing = 0;
                    QualitySettings.lodBias = 0.65f;
                    break;

                case HandFusionQuality.Balanced:
                    Application.targetFrameRate = 60;
                    QualitySettings.vSyncCount = 0;
                    QualitySettings.shadows = ShadowQuality.Disable;
                    QualitySettings.antiAliasing = 0;
                    QualitySettings.lodBias = 0.9f;
                    break;

                case HandFusionQuality.Quality:
                    Application.targetFrameRate = 60;
                    QualitySettings.vSyncCount = 0;
                    QualitySettings.shadows = ShadowQuality.HardOnly;
                    QualitySettings.antiAliasing = 2;
                    QualitySettings.lodBias = 1.15f;
                    break;
            }

            PlayerPrefs.SetInt("hf_quality", (int)quality);
            PlayerPrefs.Save();
            Changed?.Invoke(quality);
        }

        private void Awake()
        {
            Apply((HandFusionQuality)PlayerPrefs.GetInt(
                "hf_quality",
                (int)HandFusionQuality.Balanced
            ));
        }
    }
}
