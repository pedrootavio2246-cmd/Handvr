using System;
using System.Collections;
using System.Collections.Generic;
using HandFusion.Apps;
using HandFusion.Input;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace HandFusion
{
    public sealed class HandFusionBootstrap : MonoBehaviour
    {
        private readonly Dictionary<string, IHandFusionApp> _apps = new();
        private readonly Dictionary<string, SpatialWindow> _windows = new();

        private Camera _camera;
        private Canvas _canvas;
        private RectTransform _desktop;
        private RectTransform _windowLayer;
        private RectTransform _reticleLayer;
        private RectTransform _toast;
        private Text _toastText;
        private RectTransform _dock;
        private Text _statusText;
        private HandInputRouter _inputRouter;
        private HandFusionPerformance _performance;

        private float _fpsAccumulator;
        private int _fpsSamples;
        private float _nextStatusUpdate;

        public float AverageFps =>
            _fpsSamples > 0 ? _fpsAccumulator / _fpsSamples : 0f;

        private void Awake()
        {
            DontDestroyOnLoad(gameObject);
            BuildRuntime();
        }

        private void Update()
        {
            var fps = 1f / Mathf.Max(Time.unscaledDeltaTime, 0.0001f);
            _fpsAccumulator += fps;
            _fpsSamples++;

            if (Time.unscaledTime >= _nextStatusUpdate)
            {
                _nextStatusUpdate = Time.unscaledTime + 0.25f;

                if (_statusText != null && _inputRouter != null)
                {
                    _statusText.text =
                        $"{Mathf.RoundToInt(fps)} FPS  •  " +
                        $"{_inputRouter.VisibleHandCount} mãos  •  " +
                        _inputRouter.DebugState;
                }
            }
        }

        private void BuildRuntime()
        {
            _camera = Camera.main;
            if (_camera == null)
            {
                var cameraObject = new GameObject(
                    "Main Camera",
                    typeof(Camera),
                    typeof(AudioListener)
                );
                cameraObject.tag = "MainCamera";
                _camera = cameraObject.GetComponent<Camera>();
            }

            _camera.clearFlags = CameraClearFlags.SolidColor;
            _camera.backgroundColor = HandFusionTheme.Background;
            _camera.nearClipPlane = 0.01f;
            _camera.farClipPlane = 100f;

            var eventSystem = FindFirstObjectByType<EventSystem>();
            if (eventSystem == null)
            {
                var eventObject = new GameObject(
                    "EventSystem",
                    typeof(EventSystem),
                    typeof(StandaloneInputModule)
                );
                eventSystem = eventObject.GetComponent<EventSystem>();
            }

            _performance = gameObject.AddComponent<HandFusionPerformance>();

            CreateCanvas();
            CreateEnvironment();
            CreateStatusBar();
            CreateDock();
            CreateToast();

            var providerObject = new GameObject("HandTrackingProvider");
            providerObject.transform.SetParent(transform, false);
            var mediaPipe =
                providerObject.AddComponent<MediaPipeJsonProvider>();

            var fallbackObject = new GameObject("FallbackPointerProvider");
            fallbackObject.transform.SetParent(transform, false);
            var fallback =
                fallbackObject.AddComponent<EditorPointerProvider>();

            var inputObject = new GameObject("HandInputRouter");
            inputObject.transform.SetParent(transform, false);
            _inputRouter = inputObject.AddComponent<HandInputRouter>();
            _inputRouter.Configure(
                mediaPipe,
                fallback,
                _camera,
                _canvas.GetComponent<GraphicRaycaster>(),
                eventSystem,
                _reticleLayer
            );

            RegisterApps();
            BuildDockButtons();
            OpenApp("home");
            ShowToast("HandFusion Native Alpha iniciado.");
        }

        private void CreateCanvas()
        {
            var canvasObject = new GameObject(
                "SpatialCanvas",
                typeof(RectTransform),
                typeof(Canvas),
                typeof(CanvasScaler),
                typeof(GraphicRaycaster)
            );

            _canvas = canvasObject.GetComponent<Canvas>();
            _canvas.renderMode = RenderMode.WorldSpace;
            _canvas.worldCamera = _camera;
            _canvas.sortingOrder = 10;

            var canvasRect =
                canvasObject.GetComponent<RectTransform>();
            canvasRect.sizeDelta = new Vector2(1920f, 1080f);
            canvasRect.position =
                _camera.transform.position +
                _camera.transform.forward * 2.15f;
            canvasRect.rotation = _camera.transform.rotation;
            canvasRect.localScale = Vector3.one * 0.00155f;

            var scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode =
                CanvasScaler.ScaleMode.ConstantPixelSize;
            scaler.scaleFactor = 1f;

            _desktop = SpatialUIFactory.CreatePanel(
                canvasRect,
                "Desktop",
                new Color(0.03f, 0.07f, 0.13f, 0.92f),
                new Vector2(1880f, 1040f)
            );
            _desktop.anchorMin = _desktop.anchorMax =
                new Vector2(0.5f, 0.5f);
            _desktop.anchoredPosition = Vector2.zero;

            _windowLayer = SpatialUIFactory.CreatePanel(
                _desktop,
                "WindowLayer",
                new Color(0f, 0f, 0f, 0f),
                new Vector2(1820f, 850f)
            );
            _windowLayer.anchorMin = _windowLayer.anchorMax =
                new Vector2(0.5f, 0.5f);
            _windowLayer.anchoredPosition = new Vector2(0f, 42f);
            _windowLayer.GetComponent<Image>().raycastTarget = false;

            _reticleLayer = SpatialUIFactory.CreatePanel(
                _desktop,
                "ReticleLayer",
                new Color(0f, 0f, 0f, 0f),
                _desktop.sizeDelta
            );
            SpatialUIFactory.Stretch(_reticleLayer);
            _reticleLayer.GetComponent<Image>().raycastTarget = false;
            _reticleLayer.SetAsLastSibling();
        }

        private void CreateEnvironment()
        {
            var world = GameObject.CreatePrimitive(
                PrimitiveType.Sphere
            );
            world.name = "AmbientSphere";
            world.transform.position = _camera.transform.position;
            world.transform.localScale = Vector3.one * 30f;

            var material = new Material(
                Shader.Find("Unlit/Color")
            )
            {
                color = new Color(0.015f, 0.025f, 0.05f, 1f)
            };
            world.GetComponent<Renderer>().material = material;
            world.GetComponent<Collider>().enabled = false;
        }

        private void CreateStatusBar()
        {
            var statusBar = SpatialUIFactory.CreatePanel(
                _desktop,
                "StatusBar",
                new Color(0.04f, 0.08f, 0.15f, 0.96f),
                new Vector2(1800f, 78f)
            );
            statusBar.anchorMin = statusBar.anchorMax =
                new Vector2(0.5f, 1f);
            statusBar.anchoredPosition = new Vector2(0f, -48f);

            var brand = SpatialUIFactory.CreateText(
                statusBar,
                "Brand",
                "<b>HandFusion</b>  Native Alpha",
                30,
                HandFusionTheme.Text,
                TextAnchor.MiddleLeft
            );
            brand.rectTransform.anchorMin = new Vector2(0f, 0f);
            brand.rectTransform.anchorMax = new Vector2(0.45f, 1f);
            brand.rectTransform.offsetMin = new Vector2(28f, 0f);
            brand.rectTransform.offsetMax = Vector2.zero;

            _statusText = SpatialUIFactory.CreateText(
                statusBar,
                "Status",
                "Iniciando...",
                25,
                HandFusionTheme.TextMuted,
                TextAnchor.MiddleRight
            );
            _statusText.rectTransform.anchorMin = new Vector2(0.45f, 0f);
            _statusText.rectTransform.anchorMax = Vector2.one;
            _statusText.rectTransform.offsetMin = Vector2.zero;
            _statusText.rectTransform.offsetMax =
                new Vector2(-28f, 0f);
        }

        private void CreateDock()
        {
            _dock = SpatialUIFactory.CreatePanel(
                _desktop,
                "Dock",
                new Color(0.06f, 0.11f, 0.20f, 0.98f),
                new Vector2(1510f, 108f)
            );
            _dock.anchorMin = _dock.anchorMax =
                new Vector2(0.5f, 0f);
            _dock.anchoredPosition = new Vector2(0f, 69f);
            SpatialUIFactory.AddHorizontalLayout(
                _dock.gameObject,
                13f,
                18
            );
        }

        private void CreateToast()
        {
            _toast = SpatialUIFactory.CreatePanel(
                _desktop,
                "Toast",
                new Color(0.08f, 0.15f, 0.25f, 0.98f),
                new Vector2(790f, 125f)
            );
            _toast.anchorMin = _toast.anchorMax =
                new Vector2(0.5f, 0f);
            _toast.anchoredPosition = new Vector2(0f, 185f);
            _toast.gameObject.SetActive(false);

            _toastText = SpatialUIFactory.CreateText(
                _toast,
                "Text",
                "",
                28,
                HandFusionTheme.Text
            );
            SpatialUIFactory.Stretch(_toastText.rectTransform, 24f);
        }

        private void RegisterApps()
        {
            AddApp(new HomeApp());
            AddApp(new BrowserApp());
            AddApp(new CinemaApp());
            AddApp(new CalculatorApp());
            AddApp(new TargetPracticeApp());
            AddApp(new StoreApp());
            AddApp(new SettingsApp());
            AddApp(new TesterApp());
        }

        private void AddApp(IHandFusionApp app)
        {
            _apps[app.Id] = app;
        }

        private void BuildDockButtons()
        {
            foreach (var app in _apps.Values)
            {
                var localApp = app;
                var button = SpatialUIFactory.CreateButton(
                    _dock,
                    $"Dock_{app.Id}",
                    $"{app.Icon}\n<size=20>{app.DisplayName}</size>",
                    () => OpenApp(localApp.Id),
                    app.Id == "home"
                        ? HandFusionTheme.Primary
                        : HandFusionTheme.SurfaceRaised,
                    new Vector2(165f, 78f)
                );
                SpatialUIFactory.SetLayout(
                    button.gameObject,
                    165f,
                    78f
                );
            }
        }

        public void OpenApp(string id)
        {
            if (!_apps.TryGetValue(id, out var app))
            {
                ShowToast($"Aplicativo '{id}' não encontrado.");
                return;
            }

            if (_windows.TryGetValue(id, out var existing))
            {
                existing.gameObject.SetActive(true);
                existing.BringToFront();
                return;
            }

            SpatialWindow window = null;
            window = SpatialWindow.Create(
                _windowLayer,
                app.Id,
                $"{app.Icon}  {app.DisplayName}",
                app.PreferredSize,
                () =>
                {
                    if (window != null)
                    {
                        Destroy(window.gameObject);
                    }
                    _windows.Remove(id);
                }
            );

            _windows[id] = window;

            var services = new HandFusionServices
            {
                Bootstrap = this,
                Performance = _performance,
                InputRouter = _inputRouter,
                OpenApp = OpenApp,
                ShowToast = ShowToast,
                GetApps = () => new List<IHandFusionApp>(_apps.Values)
            };

            app.Build(window.Content, services);
            window.BringToFront();
        }

        public void ShowToast(string message)
        {
            if (_toast == null)
            {
                return;
            }

            _toastText.text = message;
            _toast.gameObject.SetActive(true);
            _toast.SetAsLastSibling();
            StopCoroutine(nameof(HideToastRoutine));
            StartCoroutine(HideToastRoutine());
        }

        private IEnumerator HideToastRoutine()
        {
            yield return new WaitForSecondsRealtime(3.2f);
            _toast.gameObject.SetActive(false);
        }

        public void RecenterDesktop()
        {
            var canvasRect = _canvas.GetComponent<RectTransform>();
            canvasRect.position =
                _camera.transform.position +
                _camera.transform.forward * 2.15f;
            canvasRect.rotation = _camera.transform.rotation;
            ShowToast("Interface recentralizada.");
        }
    }
}
