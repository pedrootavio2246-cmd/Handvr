using UnityEngine;

namespace HandFusion
{
    public static class HandFusionTheme
    {
        public static readonly Color Background = Hex("#07101D");
        public static readonly Color Surface = Hex("#111C2E");
        public static readonly Color SurfaceRaised = Hex("#192942");
        public static readonly Color SurfaceHover = Hex("#23446B");
        public static readonly Color Primary = Hex("#62B5FF");
        public static readonly Color PrimaryPressed = Hex("#2B82D8");
        public static readonly Color Secondary = Hex("#9D8CFF");
        public static readonly Color Text = Hex("#F3F8FF");
        public static readonly Color TextMuted = Hex("#9FB2CC");
        public static readonly Color Success = Hex("#5EF1A7");
        public static readonly Color Warning = Hex("#FFD65A");
        public static readonly Color Danger = Hex("#FF6B7C");
        public static readonly Color ReticleLeft = Hex("#59F7AD");
        public static readonly Color ReticleRight = Hex("#59B9FF");

        public static Color Hex(string value)
        {
            if (ColorUtility.TryParseHtmlString(value, out var color))
            {
                return color;
            }

            return Color.white;
        }
    }
}
